const dotenv = require('dotenv');
dotenv.config({path: '../../.env'});

const MongoClient = require('mongodb').MongoClient;

const connectionUrl = 'mongodb://localhost:27017';
const errorLog = require('../ErrorLog/errorLog');


let today = new Date();
let todayString = today.toLocaleString();

async function createLog(date, category, productName, amount, location, user, userRole) {
    try {
        await MongoClient.connect(connectionUrl, {useUnifiedTopology: true}, (error, client) => {
            if (error) throw new Error(error);

            const database = client.db(process.env.MONGODATABASE);

            const userlogCollection = database.collection(process.env.MONGODB_COLLECTION);

            userlogCollection.insertOne({
                date: date,
                action: 'Create',
                category: category,
                productName: productName,
                amount: amount,
                location: location,
                userName: user,
                userRole: userRole,

            }, (error, result) => {
                if (error) throw new Error(error);
                client.close();
            });
        });
    } catch (error) {
        await errorLog.logError(error);
    }
}

/*createLog('22-4-2021 @ 13:45', 'Create', 'TestDate', 123, 'VCK_KBH', 'Nicholas', 'Master');
createLog('2-4-2021 @ 13:45', 'Create', 'TestDate', 123, 'VCK_KBH', 'Nicholas', 'Master');
createLog('10-5-2021 @ 13:45', 'Create', 'TestDate', 123, 'VCK_KBH', 'Nicholas', 'Master');
createLog('17-2-2021 @ 13:45', 'Create', 'TestDate', 123, 'VCK_KBH', 'Nicholas', 'Master');
createLog('17-5-2021 @ 13:45', 'Create', 'TestDate', 123, 'VCK_KBH', 'Nicholas', 'Master');
createLog('7-4-2021 @ 13:45', 'Create', 'TestDate', 123, 'VCK_KBH', 'Nicholas', 'Master');
createLog('15-4-2021 @ 13:45', 'Create', 'TestDate', 123, 'VCK_KBH', 'Nicholas', 'Master');
createLog('23-5-2021 @ 13:45', 'Create', 'TestDate', 123, 'VCK_KBH', 'Nicholas', 'Master');
createLog('18-5-2021 @ 13:45', 'Create', 'TestDate', 123, 'VCK_KBH', 'Nicholas', 'Master');
createLog('11-4-2021 @ 13:45', 'Create', 'TestDate', 123, 'VCK_KBH', 'Nicholas', 'Master');
createLog('14-5-2021 @ 13:45', 'Create', 'TestDate', 123, 'VCK_KBH', 'Nicholas', 'Master');

 */

async function updateLog(id, ProductName, price, description, type, stockId, user, userRole) {
    try {
        await MongoClient.connect(connectionUrl, {useUnifiedTopology: true}, (error, client) => {
            if (error) throw new Error(error);

            const database = client.db('FridayGroupMDB');

            const userlogCollection = database.collection('userlog');

            userlogCollection.insertOne({
                date: todayString,
                action: 'Update',
                id: id,
                productName: productName,
                price: price,
                description: description,
                type: type,
                stockId, stockId,
                userName: user,
                userRole: userRole
            }, (error, result) => {
                if (error) throw new Error(error);
                client.close();
            });
        });
    } catch (error) {
        await errorLog(error);
    }
}

async function deleteLog(id, productName, category, location, user, userRole) {
    try {
        await MongoClient.connect(connectionUrl, {useUnifiedTopology: true}, (error, client) => {
            if (error) throw new Error(error);

            const database = client.db('FridayGroupMDB');

            const userlogCollection = database.collection('userlog');

            userlogCollection.insertOne({
                date: todayString,
                action: 'Delete',
                id: id,
                productName: productName,
                category: category,
                location: location,
                userName: user,
                userRole: userRole
            }, (error, result) => {
                if (error) throw new Error(error);
                client.close();
            });
        });
    } catch (error) {
        await errorLog(error);
    }
}

//logUserAction('ADD','Alkohol','Absolute Vodka','20','Patrick','Jønsson','Supreme leader');

function getUserLog() {
    return new Promise((resolve, reject) => {
        try {
            MongoClient.connect(connectionUrl, {useUnifiedTopology: true}, (error, client) => {
                if (error) throw new Error(error);

                const database = client.db('FridayGroupMDB');

                const userlogCollection = database.collection('userlog');

                userlogCollection.find().toArray((error, foundLogs) => {
                    if (error) console.log(error);

                    console.log(foundLogs);
                    client.close();
                    resolve(foundLogs);
                    return foundLogs;

                });
            });
        } catch (error) {
            reject.console.log(error);
        }
    });
}
//getUserLog();




module.exports = {
    createLog,
    getUserLog,
    updateLog,
    deleteLog
};

 */