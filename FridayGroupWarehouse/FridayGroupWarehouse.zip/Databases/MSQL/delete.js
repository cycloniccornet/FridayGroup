const dotenv = require('dotenv');
dotenv.config({path: '../../.env'});
const sql = require('mssql');

const userlog = require('../MongoDB/UserLog/userlog.js');
const readProduct = require('../MSQL/read.js');

const config = {
    user: process.env.DB_USERNAME,
    password: process.env.DB_PASSWORD,
    server: process.env.DB_LOCATION,
    database: process.env.DB_NAME,
    "options": {
        "encrypt": true,
        "enableArithAbort": true
    }
};

async function deleteProduct(id) {
    try {
        let pool = await sql.connect(config);

        let productInfo = await readProduct.getProductDataFromGeneralStockToMDB(id);

        await userlog.deleteLog(productInfo[0].id, productInfo[0].stock_product_name, productInfo[0].product_type_name, productInfo[0].location_name, "Some Name", "Some user role");

        return await pool.request()
            .input('input_parameter', sql.Int, id)
            .query("DELETE FROM stock.general_stock where id = @input_parameter");
    } catch (error) {
        console.log(error);
    }
}


async function deleteProductFromStockProduct(id) {
    try {
        let pool = await sql.connect(config);
        const deletedItem = await pool.request()
            .input('input_parameter', sql.Int, id)
            .query("DELETE FROM stock.stock_product where stock_product_id = @input_parameter");
        return deletedItem
    } catch (error) {
        console.log(error)
    }
}

async function removeProductFromSpecificWarehouse(id) {
    try {
        let pool = await sql.connect(config);
        return await pool.request()
            .input('id', sql.Int, id)
            .query("DELETE FROM stock.general_stock WHERE id = @id")
    } catch (error) {
        console.log(error)
    }
}


module.exports = {
    deleteProduct,
    deleteProductFromStockProduct,
    removeProductFromSpecificWarehouse
};