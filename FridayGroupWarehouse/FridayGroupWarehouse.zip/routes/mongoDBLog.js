const router = require('express').Router();

const userlog = require('../Databases/MongoDB/Userlog/userlog.js');


router.get("/mongoDb/allLogs", async (req, res) => {

    const allUserLogs = await userlog.getUserLog();
    res.status(200).send({
        data: allUserLogs
    });
});

module.exports = router;