const router = require('express').Router();
const nMailer = require('../nodemailer/nodemailer.js');

router.get('/mailerLog', (req, res) =>{
    nMailer.statusMail(req.session.mail).catch(console.error);
    return res.status(200).send({ data: 'Mail send successfully'});
});



module.exports = router;