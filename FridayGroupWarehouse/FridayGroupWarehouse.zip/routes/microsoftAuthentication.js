const router = require('express').Router();
const msal = require('@azure/msal-node');

const loginConfig = {
    auth: {
        clientId: process.env.LOGIN_CLIENT_ID, // The Application (client) ID that the Azure portal – App registrations experience assigned to your app.
        authority: process.env.LOGIN_AUTHORITY, // The Application (client) ID of the application you registered.
        clientSecret: process.env.LOGIN_CLIENT_SECRET // A secret string that the application uses to prove its identity when requesting a token. Also can be referred to as application password.
    },
    system: {
        loggerOptions: {
            loggerCallback(loglevel, message, containsPii) {
                console.log(message);
            },
            piiLoggingEnabled: false,
            logLevel: msal.LogLevel.Verbose,
        }
    }
};

// Constructor for the ConfidentialClientApplication
const cca = new msal.ConfidentialClientApplication(loginConfig);

router.get('/loginMicrosoft', (req, res) => {
    //console.log("Inde i loginMicrosoft")
    const authCodeUrlParameters = {
        //(user.read) = "Sign you in and read your profile"
        scopes: ["user.read"], //This is a Microsoft extension to the authorization code flow, intended to allow apps to declare the resource they want the token for during token redemption.
        redirectUri: process.env.LOGIN_REDIRECT_URI, //The redirect_uri of your app, where authentication responses can be sent and received by your app.
    };

    // Get url to sign user in and consent to scopes needed for application
    // Creates the URL of the authorization request
    cca.getAuthCodeUrl(authCodeUrlParameters)
        .then((response) => {
        res.redirect(response);
    })
        .catch((error) => console.log(JSON.stringify(error)));
});

router.get('/redirect', (req, res) => {
    const tokenRequest = {
        code: req.query.code,
        scopes: ["user.read"],
        redirectUri: process.env.LOGIN_REDIRECT_URI,
    };

    // Acquires a token by exchanging the Authorization Code received from the first step of OAuth2.0
    cca.acquireTokenByCode(tokenRequest).then((response) => {
        console.log("\nResponse From Login: \n:", response);

        //session cookie
        req.session.username = response.account.name;
        req.session.mail = response.account.mail;

        return res.status(200).redirect('/overview');
    }).catch((error) => {
        console.log(error);
        res.status(500).send(error);
    });
});

router.get('/getSessionCookie', (req, res) => {
    if(req.session.username !== undefined) {
        return res.send({
            username: req.session.username
        });
    } else {
        res.status(200).send({
            username: req.session.username
        });
    }
});

module.exports = router;