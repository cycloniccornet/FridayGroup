const router = require('express').Router();
const insertProduct = require('../Databases/MSQL/create');
const deleteProduct = require('../Databases/MSQL/delete');
const updateProduct = require('../Databases/MSQL/update.js');
const readProduct = require('../Databases/MSQL/read.js');
const mongoDbLog = require('../Databases/MongoDB/UserLog/userlog.js')
// const podio = require('../podio/podioBookings');

router.get('/getDataFromDB', async (req, res) => {
    const products = await readProduct.getAllProducts();
    return res.status(200).send({
        data: products.data
    })
});
/*
router.get('/test', (req, res) => {
    podio.getHeaders().then(r => console.log("Result from test", r));
});

 */

router.post('/insert', async (req, res) => {
    //console.log(req.body);

    const insertProd = await insertProduct.insert(
        req.body.name,
        req.body.quantity,
        req.body.price,
        req.body.description,
        req.body.location,
        req.body.category
    );
    //console.log("insertProd from router", insertProd);
    if (insertProd !== undefined) {
        return res.status(200).send({

            data: 'Success'
        })
    } else {
        return res.status(500).send({
            data: 'Something went wrong'
        });
    }
});

router.delete('/deleteProduct/:id', async (req, res) => {
    const product = await deleteProduct.deleteProduct(
        req.params.id
    )
    return res.status(200).send(
        product
    )
});

router.put('/updateProduct/:id', async (req, res) => {
    const product = await updateProduct.updateProduct(
        req.params.id,
        req.body.name,
        req.body.unitPrice,
        req.body.description,
        req.body.productType,
        req.body.stockId
    );
    return res.status(200).send({
        product
    })
});

router.get('/getProduct/:id', async (req, res) => {
    const product = await readProduct.getProduct(req.params.id);
    return res.status(200).send({
        product
    })
});

router.get('/getProductTypes', async (req, res) => {
    const productTypes = await readProduct.getProductTypes();
    return res.status(200).send({
        types: productTypes
    })
});

router.put('/updateProductType/:id', async (req, res) => {
    const update = await updateProduct.updateProductType(req.params.id, req.body.productTypeId);
    return res.status(200).send({
        product_type: update
    })
});

router.patch('/updateProductAmount', async (req, res) => {
    const updateAmount = await updateProduct.updateProductAmount(req.body.id, req.body.amount);
    if (updateAmount.rowsAffected[0] === 1) {
        return res.status(200).send({
            data: 'Success.'
        })
    } else {
        return res.status(200).send({
            data: 'Failed to update amount.'
        })
    }
});

router.post('/addNewProduct', async (req, res) => {
    const SQLadd = await insertProduct.createNewProduct(req.body.name, req.body.price, req.body.description);
    if (SQLadd.rowsAffected[0] === 1) {
        return res.status(200).send({
            data: 'Nyt produkt oprettet'
        })
    } else {
        return res.status(500).send({
            data: 'Nyt produkt blev ikke oprettet.'
        })
    }
})

router.get('/getAllProductItems', async (req, res) => {
    const productItems = await readProduct.getAllProductItems();
    if (productItems.products.recordset.length > 0) {
        return res.status(200).send({
            data: productItems.products
        })
    } else {
        return res.status(500).send({
            data: 'Failed to get products.'
        })
    }
})

router.delete('/removeProduct', async (req, res) => {
    const deletedItem = await deleteProduct.deleteProductFromStockProduct(req.body.id);
    if (deletedItem.rowsAffected[0] === 1) {
        return res.status(200).send({
            data: 'Succesfully deleted item.'
        })
    } else {
        return res.status(500).send({
            data: 'Failed to delete item.'
        })
    }
})

router.get('/getLocations', async (req, res) => {
    const locations = await readProduct.getAllLocations();
    if (locations.locations.recordset.length > 1) {
        return res.status(200).send({
            data: locations
        })
    } else {
        return res.status(500).send({
            data: 'Failed to get locations.'
        })
    }
})

router.post('/addProductToWarehouse', async (req, res) => {
    const productTypeId = await readProduct.getLocationIdByStockProductId(req.body.productId)
    const productType = productTypeId.product.recordset[0].product_type_fk;
    const addedProduct = await insertProduct.addProductToWarehouse(req.body.locationId, req.body.productId, productType);
    if (addedProduct.rowsAffected[0] === 1) {
        console.log('Produktet blev successfuldt tilføjet varelager')
        return res.status(200).send({
            data: addedProduct
        })
    } else {
        return res.status(500).send({
            data: 'Failed to add product to location.'
        })
    }
})

router.delete('/removeProductFromWarehouse', async (req, res) => {
    const deletedProduct = await deleteProduct.removeProductFromSpecificWarehouse(req.body.productId);
    res.status(200).send({
        data: deletedProduct
    })
})

module.exports = router;