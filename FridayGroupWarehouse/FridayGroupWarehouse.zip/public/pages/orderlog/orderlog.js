(() => {
    fetch('/mongoDb/allLogs')
        .then(log => log.json())
        .then(logs => {
            let i;

            let today = new Date();

            let currentDay = today.toLocaleString();
            let currentSeperate = currentDay.split(" ")[0];
            let replaceSlash = currentSeperate.replaceAll("/", ".");
            let finalToday = replaceSlash.replace(",", "");



            let minusToday = new Date();

            minusToday.setDate(minusToday.getDate() - 7);

            let minusDays = minusToday.toLocaleString();
            let splitMinusDays = minusDays.split(" ")[0];
            let todayReplaceSlash = splitMinusDays.replaceAll("/", ".");
            let finalMinusString = todayReplaceSlash.replace(",", "");


            for (i = 0; i < logs.data.length; i++) {
                let day = logs.data[i].date;
                console.log(day.split(" ")[0], " Minus days: ", finalMinusString);
                console.log(finalToday);
//                if (day.split(" ")[0] === finalToday) {
                    $('.tbody').append(
                        '<tr>' +
                        '<th scope="row">' + logs.data[i].date + '</th>' +
                        '<td>' + logs.data[i].userName + '</td>' +
                        '<td>' + logs.data[i].action + '</td>' +
                        '<td>' + logs.data[i].category + '</td>' +
                        '<td>' + logs.data[i].productName + '</td>' +
                        '<td>' + logs.data[i].location + '</td>' +
                        '</tr>'
                    )
                }
  //          }
            console.log("done")
        })
        .catch(reason => console.log(reason));
})();



function sendMail(){

    fetch('/mailerLog')
        .then(mailLog => mailLog.json())
        .then(mailLogs => {
            console.log("fetch for mail", mailLogs);
        });
};


