$(document).ready(function () {
    //get value test
    $('#submitButton').click(function () {
        let name = $('#productname').val();
        let quantity = $('#quantity').val();
        let price = $('#price').val();
        let description = $('#description').val();
        let location = $('#locationId').val();
        let category = $('#categoryId').val();

        console.log(name, quantity, price, description, location, category)

        fetch ('/insert', {
            method: 'POST',
            headers: {'content-type': 'application/json'},
            body: JSON.stringify({name, quantity, price, description, location, category})
        })
            .then(response => response.json())
            .then(response => {
                if (response.data === "Success") {
                    alert("Product created");
                    window.location = "/overview";
                } else {
                    alert("Something went wrong. Try again");
                }
            })
            .catch(err => err);


    });
});
