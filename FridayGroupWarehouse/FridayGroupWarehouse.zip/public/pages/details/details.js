const urlArray = window.location.href.split("/");
const productId = urlArray[urlArray.length - 1];

let detailed_product = null;

fetch('/getProduct/'+productId)
    .then(result => result.json())
    .then(result => {
        detailed_product = result
        $('#detailed_product').append(
            '<h1>'+result.product.product[0].stock_product_name+'</h1>' +
            '<table>' +
            '<tr><td>Unit Price</td><td>'+result.product.product[0].unit_price+' kr.</td></tr>' +
            '<tr><td>Product Description</td><td id="product_description"></td></tr>' +
            '<tr><td>Product Type</td><td>'+result.product.product[0].product_type_name+'</td></tr>' +
            '</table>' +
            '<h3>Oversigt over lager</h3>' +
            '<div>' +
            '<table id="stock_hold">' +
            '<th>Lokation</th>' +
            '<th>Antal på lager</th>' +
            '</table>' +
            '</div>'
        )
        if (result.product.product[0].product_description === null || detailed_product.product.product[0].product_description === '') {
            $('#product_description').append(
                'Ingen beskrivelse'
            )
        } else {
            $('#product_description').append(result.product.product[0].product_description)
        }

        for (let i = 0;i<result.product.locations.length;i++) {

            let productAmount = '';

            if (result.product.locations[i].quantity === null || result.product.locations[i].quantity === '') {
                productAmount = 0;
            } else {
                productAmount = result.product.locations[i].quantity;
            }

            $('#stock_hold').append(
                '<tr><td>'+convertName(result.product.locations[i].location_name)+'</td><td>'+productAmount+'</td></tr>'
            )
        }

        $('#detailed_product').append(
            '<br><button class="btn btn-primary" onclick="editMode()" id="update_button">Rediger oplysninger</button>' +
            '<button class="btn btn-danger" onclick="deleteProduct()">Slet produkt</button>'
        )
    })

function deleteProduct() {
    if (confirm('Er du sikker på at du vil slette produktet?\n' +
        'Produktet samt alle tilhørende værdier vil blive slettet!')) {

        fetch('/deleteProduct/'+productId, {
            method: 'DELETE',
        })
            .then(result => result.json())
            .then(result => {
                console.log(result.rowsAffected[0]);
                if (result.rowsAffected[0] === 1) {
                    alert("Product successfully deleted.");
                    window.location.href = '/overview'
                }
            })
    }
}

function convertName(name) {
    if (name === 'vck_kbh') {
        return 'Virtuelt Cocktailkursus - København'
    } if (name === 'inv_cc_kbh') {
        return 'Inventar Cocktail Company - København'
    } if (name === 'inv_cc_aarhus') {
        return 'Inventar Cocktail Company - Århus'
    } if (name === 'cc_kbh') {
        return 'Cocktail Company - København'
    } if (name === 'cc_aarhus') {
        return 'Cocktail Company - Århus'
    } if (name === 'potio_kbh') {
        return 'Potio - København'
    } if (name === 'potio_aarhus') {
        return 'Potio - Århus'
    } if (name === 'itf_kbh') {
        return 'Is Til Fest - København'
    } if (name === 'itf_aarhus') {
        return 'Is Til Fest - Århus'
    } if (name === 'knabro') {
        return 'Knabro'
    } if (name === 'spons_kbh') {
        return 'Spons - København'
    }
}

async function editMode() {

    let types = null;
    await fetch('/getProductTypes')
        .then(result => result.json())
        .then(result => types = result)

    console.log(types.types.types.recordset[0].product_type_name);
    console.log(detailed_product.product.product[0]);

    $('#detailed_product').empty().append(
        '<h1>'+detailed_product.product.product[0].stock_product_name+'</h1>' +
        '<form id="update_form">\n' +
        '  <div class="form-group">\n' +
        '    <label for="exampleInputEmail1">Produkt Navn</label>\n' +
        '    <br><input type="text" class="input_styling" id="stock_product_name" aria-describedby="emailHelp" value="'+detailed_product.product.product[0].stock_product_name+'">\n' +
        '  </div>\n' +
        '  <div class="form-group">\n' +
        '    <label for="exampleInputPassword1">Pris per enhed</label>\n' +
        '    <br><input type="text" class="input_styling" id="unit_price" value="'+detailed_product.product.product[0].unit_price+'">\n' +
        '  </div>\n' +
        '  <div class="form-group">\n' +
        '    <label for="exampleInputPassword1">Produkt Information</label>\n' +
        '    <br><input type="text" class="input_styling" id="product_description" placeholder="Ingen beskrivelse">\n' +
        '  </div>\n' +
        '  <div class="form-group">\n' +
        '    <label for="exampleInputPassword1">Produkt Type</label>\n' +
        '    <br><select class="input_styling" id="product_type_name"></select>\n' +
        '  </div>\n' +
        '</form>' +
        '<div><br><button class="btn btn-success" onclick="updateProduct()" id="update_button">Opdater</button><a href="/details/'+productId+'"><button class="btn btn-danger">Annuller</button></a></div>'
    )
    if (detailed_product.product.product[0].product_description !== null || detailed_product.product.product[0].product_description !== '') {
        console.log('Kommer du her ofte?')
        $('#product_description').val(detailed_product.product.product[0].product_description)
    }

    for (let i = 0;i<types.types.types.recordset.length;i++) {
        if (types.types.types.recordset[i].product_type_id === detailed_product.product.product[0].product_type_id) {
            console.log('Typerne matcher!!')
        }
        $('#product_type_name').append('<option value="'+types.types.types.recordset[i].product_type_id+'">'+types.types.types.recordset[i].product_type_name+'</option>')
    }
}

function updateProduct() {
    let name = $('#stock_product_name').val();
    let unitPrice = $('#unit_price').val();
    let description = $('#product_description').val();
    let productType = $('#product_type_name').val();
    let stockId = detailed_product.product.product[0].stock_product_id;

    let productTypeId = $('#product_type').val();

    fetch ('/updateProductType/'+productId, {
        method: 'PUT',
        headers: {'content-type': 'application/json'},
        body: JSON.stringify({
            productTypeId
        })
    })

    fetch ('/updateProduct/'+productId, {
        method: 'PUT',
        headers: {'content-type': 'application/json'},
        body: JSON.stringify({
            name,
            unitPrice,
            description,
            productType,
            stockId
        })
    })
        .then(result => result.json())
        .then(result => {
            if (result.product.rowsAffected[0] === 1) {
                window.location.href = '/details/'+productId
            }
        })
}