

(async function () {
   fetch ("/test")
       .then(result => console.log(result))
})();