fetch('https://pakkemodelapi.azurewebsites.net/api/bookings?start=2021-05-11&end=2021-05-21')
    .then(result => result.json)
    .then(result => {
        console.log(result)
    })
    .catch(
        error => console.log(error)
    )