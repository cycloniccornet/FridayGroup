let current = 'none';

function convertName(name) {
    if (name === 'vck_kbh') {
        return 'Virtuelt Cocktailkursus - København'
    } if (name === 'inv_cc_kbh') {
        return 'Inventar Cocktail Company - København'
    } if (name === 'inv_cc_aarhus') {
        return 'Inventar Cocktail Company - Århus'
    } if (name === 'cc_kbh') {
        return 'Cocktail Company - København'
    } if (name === 'cc_aarhus') {
        return 'Cocktail Company - Århus'
    } if (name === 'potio_kbh') {
        return 'Potio - København'
    } if (name === 'potio_aarhus') {
        return 'Potio - Århus'
    } if (name === 'itf_kbh') {
        return 'Is Til Fest - København'
    } if (name === 'itf_aarhus') {
        return 'Is Til Fest - Århus'
    } if (name === 'knabro') {
        return 'Knabro'
    } if (name === 'spons_kbh') {
        return 'Spons - København'
    } if (name === 'kassen') {
        return 'Kassen - København'
    } if (name === 'Test lokation') {
        return 'Test Lokation'
    }
}

function button_click(input) {
    if (input === current) {
        return;
    }
    $('#'+input).css("background", "linear-gradient(176deg, rgba(50,205,255,1) 0%, rgba(15,93,255,1) 100%)");
    $('#'+ current).css("background", "linear-gradient(176deg, rgba(148,148,148,1) 0%, rgba(150,150,150,1) 0%, rgba(255,255,255,1) 100%)");
    current = input;
    getChoice(input);
}

function getChoice(input) {
    if (input === 'add_product') {
        addProduct()
    } else if (input === 'delete_product') {
        deleteProduct()
    } else if (input === 'add_to_warehouse') {
        addToWarehouse()
    } else if (input === 'remove_from_warehouse') {
        removeFromWarehouse()
    } else {
        alert('Something went wrong...!')
    }
}

// TILFØJ NYT PRODUKT

function addProduct() {
    $('#manager_choice').empty().append(
        '<h3>Tilføj nyt produkt</h3>' +
        '<table>' +
        '<tr><td>Produkt navn: </td><td><input type="text" id="productName"></td></tr>' +
        '<tr><td>Produktets pris: </td><td><input type="text" id="productPrice"></td></tr>' +
        '<tr><td>Produkt beskrivelse: </td><td><input type="text" id="productDescription"></td></tr>' +
        '</table>' +
        '<br>' +
        '<button class="btn btn-primary" onclick="DBAddProduct()">Tilføj Produkt</button>'
    )
}

function DBAddProduct() {
    const name = $('#productName').val();
    const price = $('#productPrice').val();
    const description = $('#productDescription').val();
    fetch('/addNewProduct', {
        method: 'POST',
        headers: {'content-type': 'application/json'},
        body: JSON.stringify({
            name,
            price,
            description
        })
    })
        .then(result => result.json())
        .then(result => {
            alert('Produktet er blevet tilføjet til databasen.');
            $('#productName').val('');
            $('#productPrice').val('');
            $('#productDescription').val('');
        })
}

// SLET PRODUKTER FRA DATABASEN

function deleteProduct() {
    fetch('/getAllProductItems')
        .then(result => result.json())
        .then(result => {
            if (result.data.recordset.length > 0) {
                $('#manager_choice').empty().append('<h3>Slet eksisterende produkter</h3>' +
                    '<table id="product_table"><thead>' +
                    '<th>Produkt Navn</th>' +
                    '<th>Pris</th>' +
                    '<th>Beskrivelse</th>' +
                    '<th>Tilknyttede varelagre</th>' +
                    '<th>Total antal på varelagre</th>' +
                    '<th>Fjern</th>' +
                    '</thead></table>')
                for (let i = 0;i<result.data.recordset.length;i++) {
                    let total_quantity = result.data.recordset[i].total_quantity ? result.data.recordset[i].total_quantity : '0'
                    let locations = result.data.recordset[i].locations > 0 ? result.data.recordset[i].locations : 'Ingen'
                    let description = result.data.recordset[i].product_description ? result.data.recordset[i].product_description : 'Ingen'
                    $('#product_table').append(
                        '<tr>' +
                        '<td>'+result.data.recordset[i].stock_product_name+'</td>' +
                        '<td>'+result.data.recordset[i].unit_price+'</td>' +
                        '<td>'+description+'</td>' +
                        '<td>'+locations+'</td>' +
                        '<td>'+total_quantity+'</td>' +
                        '<td id="product'+result.data.recordset[i].stock_product_id+'"><button class="btn btn-danger" onclick="DBRemoveProduct('+result.data.recordset[i].stock_product_id+', '+total_quantity+')">Remove</button></td>' +
                        '</tr>'
                    )
                }
            } else {
                $('#manager_choice').empty().append('<h3>Failed to load products - contact the developers.</h3>')
            }
        })
    $('#manager_choice').empty().append(
        '<h3>Slet eksisterende produkter</h3>' +
        '<table>' +
        '<tr></tr>' +
        '</table>'
    )
}

function DBRemoveProduct(id, total_quantity) {
    let choice;
    if (total_quantity > 0) {
        choice = confirm('Produktet er stadig på lager i nogle varehuse!\nEr du sikker på du vil slette produktet og de tilhørende beholdninger på varelagerne?');
    } else {
        choice = confirm('Er du sikker på du vil slette produktet?');
    }
    if (choice === true) {
        fetch('/removeProduct', {
            method: 'DELETE',
            headers: {'content-type': 'application/json'},
            body: JSON.stringify({
                id
            })
        })
            .then(result => result.json())
            .then(result => {
                if (result.data === 'Succesfully deleted item.') {
                    $('#product'+id).empty().append('<p class="p_tag_deleted" >Deleted</p>')
                } else {
                    alert('Something went wrong!')
                }
            })
    }
}

// TILFØJ PRODUKTER TIL VARELAGER

function addToWarehouse() {
    fetch('/getLocations')
        .then(result => result.json())
        .then(result => {
            $('#manager_choice').empty().append(
                '<h3>Tilføj produkter til varehus</h3>' +
                '<table id="choose_table"><tr><td>Vælg varelager</td><td><select id="select_warehouse" onchange="getListOfProducts(value)"></select></td></tr>' +
                '<tr id="table_row_2"></tr>' +
                '</table>' +
                '<p id="table_row_3"></p>'
            )
            for (let i = 0; i< result.data.locations.recordset.length;i++) {
                $('#select_warehouse').append('<option value="'+result.data.locations.recordset[i].location_id+'">'+convertName(result.data.locations.recordset[i].location_name)+'</option><br>')
            }

        })
}

function getListOfProducts(location_id) {
    fetch('/getAllProductItems')
        .then(result => result.json())
        .then(result => {
            $('#table_row_2').empty().append('' +
                '   <td>Vælg vare</td>' +
                '   <td><select id="list_of_products" onchange="addConfirmButton('+location_id+', value)"></select></td>')
            for (let i = 0;i<result.data.recordset.length;i++) {
                $('#list_of_products').append('<option value="'+result.data.recordset[i].stock_product_id+'">'+result.data.recordset[i].stock_product_name+'</option>')
            }
        })
}

function addConfirmButton(locationId, productId) {
    $('#table_row_3').empty().append('<br><p><button class="btn btn-success" onclick="DBAddProductToWarehouse('+locationId+', '+productId+')">Tilføj</button></p>')
}

function DBAddProductToWarehouse(locationId, productId) {
    fetch('/addProductToWarehouse', {
        method: 'POST',
        headers: {'content-type': 'application/json'},
        body: JSON.stringify({
            locationId,
            productId
        })
    })
        .then(result => result.json())
        .then(result => {
            if (result.data.rowsAffected[0] === 1) {
                alert('Produktet er blevet tilføjet varelageret.')
                $('#manager_choice').empty()
                addToWarehouse()
            } else {
                alert('Something went wrong.. Try again later.')
            }
        })
}

// FJERN PRODUKTER FRA VARELAGER

function removeFromWarehouse() {
    fetch('/getLocations')
        .then(result => result.json())
        .then(result => {
            $('#manager_choice').empty().append(
                '<h3>Fjern produkter til varehus</h3><br>' +
                '<div id="choose_table"><tr><td>Vælg varelager</td><td><select id="select_warehouse" onchange="getListOfRemovableProducts(value)"></select></td></tr>' +
                '</div><br>' +
                '<table id="table_row_2"></table>'
            )
            for (let i = 0; i< result.data.locations.recordset.length;i++) {
                $('#select_warehouse').append('<option value="'+result.data.locations.recordset[i].location_id+'">'+convertName(result.data.locations.recordset[i].location_name)+'</option><br>')
            }
        })
}

function getListOfRemovableProducts(location_id) {
    fetch('/getDataFromDB')
        .then(result => result.json())
        .then(result => {
            $('#table_row_2').empty().append('<thead>' +
                '<th>Name</th>' +
                '<th>Pris</th>' +
                '<th>Beskrivelse</th>' +
                '<th>Total antal på varelager</th>' +
                '<th>Fjern</th>' +
                '</thead>')
            for (let i = 0;i<result.data.length;i++) {
                if (result.data[i].location_fk === parseInt(location_id)) {
                    let description = result.data[i].product_description ? result.data[i].product_description : '-'
                    let quantity = result.data[i].quantity ? result.data[i].quantity : '-'
                    $('#table_row_2').append('<tr>' +
                        '<td>'+result.data[i].stock_product_name+'</td>' +
                        '<td>'+result.data[i].unit_price+' kr.</td>' +
                        '<td>'+description+'</td>' +
                        '<td>'+quantity+' stk.</td>' +
                        '<td id="product'+result.data[i].id+'"><button class="btn btn-danger" onclick="DBRemoveProductFromWarehouse('+result.data[i].location_fk+','+result.data[i].id+')">Fjern</button></td>' +
                        '</tr>')
                }
            }
        })
}

function DBRemoveProductFromWarehouse(locationId, productId) {
    const confirmation = confirm('Er du sikker på at du vil fjerne dette produkt fra varelageret?')
    if (confirmation === true) {
        fetch('/removeProductFromWarehouse', {
            method: 'DELETE',
            headers: {'content-type': 'application/json'},
            body: JSON.stringify({
                productId
            })
        })
            .then(result => result.json())
            .then(result => {
                if (result.data.rowsAffected[0] === 1) {
                    $('#product'+productId).empty().append('<p class="p_tag_deleted" >Deleted</p>')
                } else {
                    alert('Der skete en fejl - kontakt udviklerne.')
                }
            })
    }
}