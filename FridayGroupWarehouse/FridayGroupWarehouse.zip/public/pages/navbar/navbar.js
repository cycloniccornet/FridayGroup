(() => {
    fetch('/getSessionCookie')
        .then(result => result.json())
        .then(session_cookie => {
            //checks if session has a email(if person is logged in.)
            if (session_cookie.username !== undefined) {
                $('#username').append(session_cookie.username);
            } else {
                console.log("Session cookie", session_cookie.username)
                $('#username').append('Unauthorized!');
            }
        })
        .catch(error => {
                console.log('Error', error);
            }
        )
})();