let json_data = 'null';

function get_selected_id(value) {
    if (value === 'standard_selector') {
        return;
    }
    button_click(value);
}
let current_button = 'none';

function button_click(value) {
    if (value === current_button) {
        return;
    }
    $('#'+value).css("background", "linear-gradient(176deg, rgba(50,205,255,1) 0%, rgba(15,93,255,1) 100%)");
    $('#'+ current_button).css("background", "linear-gradient(176deg, rgba(148,148,148,1) 0%, rgba(150,150,150,1) 0%, rgba(255,255,255,1) 100%)");
    current_button = value;
    getDataByLocation(value);
    current_button = value;
}

(() => {
    fetch('/getDataFromDB/')
        .then(result => result.json())
        .then(result => {
            json_data = result;
        })
})();

function convertName(name) {
    if (name === 'vck_kbh') {
        return 'Virtuelt Cocktailkursus - København'
    } if (name === 'inv_cc_kbh') {
        return 'Inventar Cocktail Company - København'
    } if (name === 'inv_cc_aarhus') {
        return 'Inventar Cocktail Company - Århus'
    } if (name === 'cc_kbh') {
        return 'Cocktail Company - København'
    } if (name === 'cc_aarhus') {
        return 'Cocktail Company - Århus'
    } if (name === 'potio_kbh') {
        return 'Potio - København'
    } if (name === 'potio_aarhus') {
        return 'Potio - Århus'
    } if (name === 'itf_kbh') {
        return 'Is Til Fest - København'
    } if (name === 'itf_aarhus') {
        return 'Is Til Fest - Århus'
    } if (name === 'knabro') {
        return 'Knabro'
    } if (name === 'spons_kbh') {
        return 'Spons - København'
    }
}

function getDataByLocation(location) {
    $('#warehouse_list').empty().append('<h3>'+convertName(location)+'</h3>' +
        '    <table class="table current_warehouse">\n' +
        '        <thead class="thead-dark">\n' +
        '        <tr>\n' +
        '            <th>Navn</th>\n' +
        '            <th>Produkt Type</th>\n' +
        '            <th>Beskrivelse</th>\n' +
        '            <th>Enhedspris</th>\n' +
        '            <th>Total Lager Værdi</th>\n' +
        '            <th>Genbestil ved</th>\n' +
        '            <th>Leveringstid</th>\n' +
        '            <th>Antal bestilt</th>\n' +
        '            <th>Kan bestilles</th>\n' +
        '            <th>På lager</th>\n' +
        '            <th>Tilføj/Reducér</th>\n' +
        '        </tr>\n' +
        '        </thead>\n' +
        '    </table>');

    for (let i = 0; i<json_data.data.length; i++) {
        if (location === json_data.data[i].location_name) {
            let link = '/details/'+json_data.data[i].id;
            let description = (json_data.data[i].product_description === null) ? '-' : json_data.data[i].product_description;
            let quantity = (json_data.data[i].quantity === null) ? '-' : json_data.data[i].quantity + ' stk.';
            let delivery_time = (json_data.data[i].delivery_time === null) ? '-' : json_data.data[i].delivery_time + ' days';
            let items_ordered = (json_data.data[i].amount_ordered === null) ? '-' : json_data.data[i].amount_ordered + ' stk.';
            let reorder_at = (json_data.data[i].reorder_at === null) ? '-' : json_data.data[i].reorder_at + ' stk.';
            let unit_price = (json_data.data[i].unit_price === null) ? '-' : json_data.data[i].unit_price + ' kr.';
            $('.current_warehouse').append('' +
                '<tr>' +
                '<td><a id="details_link" href="'+link+'">'+json_data.data[i].stock_product_name+'</a></td>' +
                '<td>'+json_data.data[i].product_type_name+'</td>' +
                '<td>'+description+'</td>' +
                '<td>'+unit_price+'</td>' +
                '<td id="total'+json_data.data[i].id+'">'+Math.round(json_data.data[i].unit_price * json_data.data[i].quantity * 100) / 100+' kr.</td>' +
                '<td>'+reorder_at+'</td>' +
                '<td>'+delivery_time+'</td>' +
                '<td>'+items_ordered+'</td>' +
                '<td id="product'+json_data.data[i].id+'"></td>' +
                '<td id="product_amount'+json_data.data[i].id+'"></td>' +
                '<td><span><input onclick="input_alert()" type="number" class="product_input" id="opdater'+json_data.data[i].id+'"></span><span><button onclick="updateAmount('+json_data.data[i].id+', '+json_data.data[i].quantity+', '+json_data.data[i].unit_price+', '+i+')" style="height: 30px; line-height: 20px" class="btn btn-success">Opdater</button></span></td>' +
                '</tr>');
            if (json_data.data[i].reordered === false) {
                $('#product'+json_data.data[i].id).append('<span class="glyphicon glyphicon-remove">Nej</span>');
            } else {
                $('#product'+json_data.data[i].id).append('<span class="glyphicon glyphicon-ok">Ja</span>');
            }
            $('#product_amount'+json_data.data[i].id).append(quantity)
        }
    }
}

function input_alert() {
    alert('Skriv minus foran for at trække fra varelageret..')
}

function updateAmount(id, quantity, price, i) {
    const amount = $('#opdater'+id).val();
    fetch('/updateProductAmount', {
        method: 'PATCH',
        headers: {'content-type' : 'application/json'},
        body: JSON.stringify({
            id,
            amount
        })
    })
        .then(result => result.json())
        .then(result => {
            if (result.data === 'Success.') {
                json_data.data[i].quantity += parseInt(amount);
                alert('Successfully updated amount!');
                $('#product_amount'+id).empty().append(json_data.data[i].quantity + ' stk.');
                $('#opdater'+id).val('');
                $('#total'+id).empty().append(Math.round(json_data.data[i].quantity * price * 100) / 100 +' kr.');
            } else {
                alert('Failed to update amount.')
            }
        })
}
