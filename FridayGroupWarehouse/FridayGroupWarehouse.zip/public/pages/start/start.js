let json_data = null;

function convertName(name) {
    if (name === 'vck_kbh') {
        return 'Virtuelt Cocktailkursus - København'
    } if (name === 'inv_cc_kbh') {
        return 'Inventar Cocktail Company - København'
    } if (name === 'inv_cc_aarhus') {
        return 'Inventar Cocktail Company - Århus'
    } if (name === 'cc_kbh') {
        return 'Cocktail Company - København'
    } if (name === 'cc_aarhus') {
        return 'Cocktail Company - Århus'
    } if (name === 'potio_kbh') {
        return 'Potio - København'
    } if (name === 'potio_aarhus') {
        return 'Potio - Århus'
    } if (name === 'itf_kbh') {
        return 'Is Til Fest - København'
    } if (name === 'itf_aarhus') {
        return 'Is Til Fest - Århus'
    } if (name === 'knabro') {
        return 'Knabro'
    } if (name === 'spons_kbh') {
        return 'Spons - København'
    }
}

(() => {
    fetch('/getDataFromDB/')
        .then(result => result.json())
        .then(result => {
            json_data = result;
            getCharts();
        })
})();

function getTotalValueFromWarehouse(warehouse) {
    let sum = 0;
    for (let i = 0;i<json_data.data.length;i++) {
        if (json_data.data[i].location_name === warehouse) {
            sum += json_data.data[i].unit_price * json_data.data[i].quantity;
        }
    }
    return sum;
}

function getTotalValueFromAllWarehouses() {
    let sum = 0;
    for (let i = 0;i<json_data.data.length;i++) {
        sum += json_data.data[i].unit_price * json_data.data[i].quantity;
    }
    return sum;
}

function getCharts() {

    google.charts.load('current', {'packages':['table']});
    google.charts.setOnLoadCallback(drawTable1);
    google.charts.setOnLoadCallback(drawTable2);
    google.charts.setOnLoadCallback(drawTable3);
    google.charts.setOnLoadCallback(drawTable4);

    function drawTable1() {
        const data = new google.visualization.DataTable();

        data.addColumn('string', 'Name');
        data.addColumn('string', 'Stock Value');
        data.addRows([
            [convertName('vck_kbh'), Math.round(getTotalValueFromWarehouse('vck_kbh')) + ' kr.'],
            [convertName('cc_kbh'), Math.round(getTotalValueFromWarehouse('cc_kbh')) + ' kr.'],
            [convertName('inv_cc_kbh'), Math.round(getTotalValueFromWarehouse('inv_cc_kbh')) + ' kr.'],
            [convertName('potio_kbh'), Math.round(getTotalValueFromWarehouse('potio_kbh')) + ' kr.'],
            [convertName('itf_kbh'), Math.round(getTotalValueFromWarehouse('itf_kbh')) + ' kr.'],
            ['Total Værdi - København',
                Math.round(getTotalValueFromWarehouse('vck_kbh') +
                    getTotalValueFromWarehouse('cc_kbh') +
                    getTotalValueFromWarehouse('inv_cc_kbh') +
                    getTotalValueFromWarehouse('potio_kbh') +
                    getTotalValueFromWarehouse('itf_kbh')) + ' kr.'
            ]
        ]);

        const options = {
            width: '100%',
            height: '100%',
            textAlign: 'right'
        }

        $('#warehouse_list').append('<h2>Oversigt over Københavns Afdelinger</h2><div id="chart1" ></div>');

        const table = new google.visualization.Table(document.getElementById('chart1'));

        table.draw(data, options);
    }

    function drawTable2() {
        const data = new google.visualization.DataTable();

        data.addColumn('string', 'Name');
        data.addColumn('number', 'Stock Value');
        data.addRows([
            [convertName('cc_aarhus'), getTotalValueFromWarehouse('cc_aarhus')],
            [convertName('inv_cc_aarhus'), getTotalValueFromWarehouse('inv_cc_aarhus')],
            [convertName('potio_aarhus'), getTotalValueFromWarehouse('potio_aarhus')],
            [convertName('itf_aarhus'), getTotalValueFromWarehouse('itf_aarhus')],
            ['Total Værdi - Århus',
                getTotalValueFromWarehouse('cc_aarhus') +
                getTotalValueFromWarehouse('inv_cc_aarhus') +
                getTotalValueFromWarehouse('potio_aarhus') +
                getTotalValueFromWarehouse('itf_aarhus')
            ]
        ]);

        const options = {
            width: '100%',
            height: '100%'
        }

        $('#warehouse_list').append('<h2>Oversigt over Århus` Afdelinger</h2><div id="chart2" ></div>');

        const table = new google.visualization.Table(document.getElementById('chart2'));

        table.draw(data, options);
    }

    function drawTable3() {
        const data = new google.visualization.DataTable();

        data.addColumn('string', 'Name');
        data.addColumn('number', 'Stock Value');
        data.addRows([
            [convertName('knabro'), getTotalValueFromWarehouse('knabro')],
            [convertName('spons_kbh'), getTotalValueFromWarehouse('spons_kbh')],
            ['Total Værdi - Øvrige lokationer',
                getTotalValueFromWarehouse('knabro') +
                getTotalValueFromWarehouse('spons_kbh')
            ]
        ]);

        const options = {
            width: '100%',
            height: '100%'
        }

        $('#warehouse_list').append('<h2>Oversigt over Øvrige Afdelinger</h2><div id="chart3" ></div>');

        const table = new google.visualization.Table(document.getElementById('chart3'));

        table.draw(data, options);
    }

    function drawTable4() {
        const data = new google.visualization.DataTable();

        data.addColumn('string', 'Name');
        data.addColumn('number', 'Stock Value');
        data.addRows([
            ['Total Værdi - København',
                getTotalValueFromWarehouse('vck_kbh') +
                getTotalValueFromWarehouse('cc_kbh') +
                getTotalValueFromWarehouse('inv_cc_kbh') +
                getTotalValueFromWarehouse('potio_kbh') +
                getTotalValueFromWarehouse('itf_kbh')
            ],
            ['Total Værdi - Århus',
                getTotalValueFromWarehouse('cc_aarhus') +
                getTotalValueFromWarehouse('inv_cc_aarhus') +
                getTotalValueFromWarehouse('potio_aarhus') +
                getTotalValueFromWarehouse('itf_aarhus')
            ],
            ['Total Værdi - I Alt',
                getTotalValueFromWarehouse('cc_aarhus') +
                getTotalValueFromWarehouse('inv_cc_aarhus') +
                getTotalValueFromWarehouse('potio_aarhus') +
                getTotalValueFromWarehouse('itf_aarhus') +
                getTotalValueFromWarehouse('vck_kbh') +
                getTotalValueFromWarehouse('cc_kbh') +
                getTotalValueFromWarehouse('inv_cc_kbh') +
                getTotalValueFromWarehouse('potio_kbh') +
                getTotalValueFromWarehouse('itf_kbh') +
                getTotalValueFromWarehouse('spons_kbh') +
                getTotalValueFromWarehouse('knabro')
            ]
        ]);

        const options = {
            width: '100%',
            height: '100%'
        }

        $('#warehouse_list').append('<h2>Oversigt over Samlede Afdelinger</h2><div id="chart4" ></div>');

        const table = new google.visualization.Table(document.getElementById('chart4'));

        table.draw(data, options);
    }

    google.charts.load('current', {'packages':['corechart']});
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart1);
    google.charts.setOnLoadCallback(drawChart2);


    function drawChart1() {
        const data = new google.visualization.arrayToDataTable([
            ['Location', 'Value'],
            ['VCK KBH', (getTotalValueFromWarehouse('vck_kbh') / getTotalValueFromAllWarehouses()) * 100],
            ['CC KBH', (getTotalValueFromWarehouse('cc_kbh') / getTotalValueFromAllWarehouses()) * 100],
            ['Inventar CC - KBH', (getTotalValueFromWarehouse('inv_cc_kbh') / getTotalValueFromAllWarehouses()) * 100],
            ['Potio KBH', (getTotalValueFromWarehouse('potio_kbh') / getTotalValueFromAllWarehouses()) * 100],
            ['Is Til Fest - KBH', (getTotalValueFromWarehouse('itf_kbh') / getTotalValueFromAllWarehouses()) * 100],
            ['CC Århus', (getTotalValueFromWarehouse('cc_aarhus') / getTotalValueFromAllWarehouses()) * 100],
            ['Inventar CC - Århus', (getTotalValueFromWarehouse('inv_cc_aarhus') / getTotalValueFromAllWarehouses()) * 100],
            ['Potio Århus', (getTotalValueFromWarehouse('potio_aarhus') / getTotalValueFromAllWarehouses()) * 100],
            ['Is Til Fest - Århus', (getTotalValueFromWarehouse('itf_aarhus') / getTotalValueFromAllWarehouses()) * 100],
            ['Knabro', (getTotalValueFromWarehouse('knabro') / getTotalValueFromAllWarehouses()) * 100],
            ['Spons KBH', (getTotalValueFromWarehouse('spons_kbh') / getTotalValueFromAllWarehouses()) * 100]
        ]);

        const options = {
            width: '80%',
            height: 800,
            legend: { position: 'none' },
            axes: {
                x: {
                    0: { side: 'bottom', label: 'Afdelinger'} // Top x-axis.
                },
                y: {
                    0: { side: 'left', label: 'Procent (%) af samlet lagerværdi'} // Top x-axis.
                }
            },
            bar: { groupWidth: "90%" },
            animation: {
                duration: 1500,
                easing: 'linear',
                startup: true
            }
        };

        $('#warehouse_list').append('<h2>Diagrammer over Afdelingerne</h2><h4>Søjlediagram over værdier fordelt på afdelinger</h4><div id="chart5" ></div>');

        const chart = new google.charts.Bar(document.getElementById('chart5'));
        chart.draw(data, google.charts.Bar.convertOptions(options));
    }

    function drawChart2() {
        const data = google.visualization.arrayToDataTable([
            ['Warehouse', 'Total Value'],
            [convertName('vck_kbh'), getTotalValueFromWarehouse('vck_kbh')],
            [convertName('cc_kbh'), getTotalValueFromWarehouse('cc_kbh')],
            [convertName('cc_aarhus'), getTotalValueFromWarehouse('cc_aarhus')],
            [convertName('inv_cc_kbh'), getTotalValueFromWarehouse('inv_cc_kbh')],
            [convertName('inv_cc_aarhus'), getTotalValueFromWarehouse('inv_cc_aarhus')],
            [convertName('potio_kbh'), getTotalValueFromWarehouse('potio_kbh')],
            [convertName('potio_aarhus'), getTotalValueFromWarehouse('potio_aarhus')],
            [convertName('itf_kbh'), getTotalValueFromWarehouse('itf_kbh')],
            [convertName('itf_aarhus'), getTotalValueFromWarehouse('itf_aarhus')],
            [convertName('knabro'), getTotalValueFromWarehouse('knabro')],
            [convertName('spons_kbh'), getTotalValueFromWarehouse('spons_kbh')]
        ]);

        const options = {
            chartArea:{width:'100%',height:'100%'},
            fontSize: '13',
            fontName: 'Bahnschrift',
            backgroundColor: 'transparent',
            fontcolor: 'black',
            title: 'Warehouse Overview',
            height: '500'
        }

        $('#warehouse_list').append('<h4>Kagediagram over værdier fordelt på afdelinger</h4><div id="chart6" ></div>');

        const chart = new google.visualization.PieChart(document.getElementById('chart6'));
        chart.draw(data, options);
    }
}
