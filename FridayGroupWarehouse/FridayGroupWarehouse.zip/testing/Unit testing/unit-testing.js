/// <reference types="cypress" />

// Import method
const updateProduct = require('../../Databases/MSQL/update');
const assert = require('assert');

/*
(async ()=> {
    console.log("before")
    const data = await updateProduct.updateProductAmount(1023  , "plus", 15);
    console.log(data);
    console.log("After")
})();

describe('#updateProductAmount()',   () => {
       it('should update amount of an existing product without error2',  function() {

            return updateProduct.updateProductAmount(1050  , "plus", 1000)
                .then(result => console.log("r", result));


            //data.should.include("rowsAffected: [ 1 ]")
        });
    });

 */


describe('testRoute', function () {
    it('Finds the sum of a and b', () => {
        const sum = add(2, 5)

        expect(sum).toEqual(7);
        expect(sum).not.tobe(null)
        expect(sum).not.toBeInstanceOf(Number);
    })
});






