const {Builder, By, Key, until} = require('selenium-webdriver');

//chromedriver.exe is the driver for chrome *Mind blown*

(async function example() {
    //Builds the webpage for testing in chrome
    let driver = await new Builder().forBrowser('chrome').build();

    try {
        //Goes to url
        await driver.get('http://localhost/create');

        /*
        1. Finds element where "id" mathces string.
        2. sendKeys writes the string in the chosen element
        3. key.RETURN: Return key has the same function as the Enter key
        */
        await driver.findElement(By.id('productname')).sendKeys('PTestProduct', Key.RETURN);
        await driver.findElement(By.id('quantity')).sendKeys('8', Key.RETURN);
        await driver.findElement(By.id('price')).sendKeys('100000000', Key.RETURN);
        await driver.findElement(By.id('description')).sendKeys('This is a test product', Key.RETURN);

        await driver.findElement(By.css('#locationId > option:nth-child(3)'))
            .click();

        await driver.findElement(By.css('#categoryId > option:nth-child(2)'))
            .click();

        driver.findElement(By.id('submitButton')).submit();
        //await driver.findElement(By.id('submitButton')).click();

        //await driver.wait(until.titleIs('webdriver - Google Search'), 1000);
    } finally {
        //await driver.quit();
        console.log("done")
    }
})();